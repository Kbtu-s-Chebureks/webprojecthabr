export const categories = [
    {
        id: 1,
        name: 'Math'
     },
     {
        id: 2,
        name: 'ICT',
     },
     {
        id: 3,
        name: 'Covid-19',
     },
     {
        id: 4,
        name: 'Data Science',
     }
]