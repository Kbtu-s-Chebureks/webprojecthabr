export const users = [
    {
        id: 1,
        username: 'naruto',
        password: 'password',
        name: 'Naruto',
        birthday: '2014-01-01',
        email: 'naruto@gmail.com'
     },
     {
        id: 2,
        username: 'sasuke',
        password: 'password',
        name: 'Sasuke',
        birthday: '2013-01-01',
        email: 'sasuke@gmail.com'
     },
     {
        id: 3,
        username: 'kakashi',
        password: 'password',
        name: 'Kakashi',
        birthday: '2001-01-01',
        email: 'kakashi@gmail.com' 
     },
     {
        id: 4,
        username: 'sakura',
        password: 'password',
        name: 'Sakura',
        birthday: '2001-02-01',
        email: 'sakura@gmail.com' 
     }
]